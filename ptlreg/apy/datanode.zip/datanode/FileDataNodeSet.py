from .HasDataLabels import *
from .DataNodeSet import *
from .HasDirectories import *
from .FileDataNode import *


def _endswithany(fstring, extensions):
    for e in extensions:
        if(fstring.lower().endswith(e)):
            return True;
    return False;




FILEDATANODESET_DEFULT_INDEX =HasFPath.FILE_PATH_KEY;
class HasFileDataNodeSet(HasFileDataNode):
    RELATIVE_FILE_PATH_KEY =FILEDATANODESET_DEFULT_INDEX;
    DEFAULT_INDEX_KEY = FILEDATANODESET_DEFULT_INDEX;
    SubsetClass = None;
    DATANODE_CLASS = FileDataNode;

    def getAbsolutePath(self, from_root=None):
        root_path = from_root;
        if(root_path is None):
            root_path = self.root_path;
        if(root_path is not None):
            return os.path.abspath(os.path.join(self.root_path, self.file_path));
        else:
            return os.path.abspath(self.file_path);


    def __str__(self):
        return "{}: {}".format(self.__class__.__name__, self.nodes.__str__());

    def __repr__(self):
        return self.nodes.__repr__();


    # <editor-fold desc="Property: 'root_path'">
    @property
    def root_path(self):
        return self.getLabel("root_path");
    # </editor-fold>

    def __init__(self, path=None, root_path = None, *args, **kwargs):
        """
        Initialize FileDataNode. This is a node that represents a file with a path.
        :param path: The path
        :param root_path: a root path to store this path relative to
        :param kwargs:
        """
        super(HasFileDataNodeSet, self).__init__(path=path, root_path=root_path, *args, **kwargs);


    def setRootPath(self, root_path):
        raise NotImplementedError;


    def Subset(self, *args, **kwargs):
        subset = super(HasFileDataNodeSet, self).Subset(*args, **kwargs)
        subset._setRootPath(self.root_path)
        return self.__class__.GetSubsetClass()(*args, **kwargs)

    @classmethod
    def FromDirectory(cls, directory, root_path = None, recursive=False, extension_list=None, criteriaFunc=None, include_hidden_files=False):
        """

        :param directory: absolute path to directory
        :param root_path: root path to use
        :param recursive:
        :param extension_list:
        :param criteriaFunc:
        :param include_hidden_files:
        :return:
        """
        if(root_path is None):
            root_path=directory;
        new_nodeset = cls(path=directory, root_path=root_path);
        if (not recursive):
            for filename in os.listdir(new_nodeset.getAbsolutePath()):
                if ((extension_list is None) or _endswithany(filename, extension_list)):
                    fpath = FPath(os.path.join(os.path.abspath(directory), filename));
                    include_fpath = True;
                    if(not include_hidden_files and fpath.file_name[0]=="."):
                        include_fpath = False;
                    if(criteriaFunc):
                        include_fpath = include_fpath and criteriaFunc(fpath);
                    if(include_fpath):
                        newNode = cls.DATANODE_CLASS(path=fpath.relative_path(to_path=new_nodeset.root_path), root_path=new_nodeset.root_path);
                        new_nodeset.addNode(newNode);
            return new_nodeset;
        else:
            raise NotImplementedError;
        #     for root, dirs, files in os.walk(directory):
        #         for f in files:
        #             if ((extension_list is None) or _endswithany(f, extension_list)):
        #                 fpth = FPath(os.path.join(os.path.abspath(directory), f));
        #                 FilePath(os.path.join(root, f));
        #                 if (criteriaFunc):
        #                     if (criteriaFunc(fpth)):
        #                         new_list.append(fpth);
        #                 else:
        #                     new_list.append(fpth);
        # return new_list;


class FileDataNodeSet(HasFileDataNodeSet, DataNodeSet):
    pass;
