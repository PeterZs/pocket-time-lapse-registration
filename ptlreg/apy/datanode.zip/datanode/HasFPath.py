import os
import hashlib
from .HasDataLabels import *

def _pathstring(path):
    return path.replace(os.sep+os.sep, os.sep);

def _myisdir(fpath):
    return os.path.isdir(fpath);

class HasFPath(object):
    """

    """
    FILE_PATH_KEY = "file_path"
    FILE_NAME_KEY = "file_name"

    def __init__(self, path=None, root_path=None, **kwargs):
        # self._file_path = None;
        super(HasFPath, self).__init__(**kwargs)
        if(path):
            adjusted_input_path = self._getAdjustedInputFilePath(input_file_path=path);
            self._setFilePath(file_path=adjusted_input_path, root_path=root_path, **kwargs);


    def _getAdjustedInputFilePath(self, input_file_path):
        return input_file_path;

    # <editor-fold desc="Property: 'file_path'">
    @property
    def file_path(self):
        return self.getFilePath();
    def getFilePath(self):
        return self.getLabel(HasFPath.FILE_PATH_KEY);


    @file_path.setter
    def file_path(self, value):
        self._setFilePath(value);

    def _setFilePath(self, file_path=None, root_path=None, **kwargs):
        oldpath = None;
        if(self.file_path):
            oldpath = self.getAbsolutePath();
        if(root_path):
            self._setRootPath(root_path);
        self.setLabel('file_path', os.path.normpath(file_path));
        if(oldpath):
            self.on_path_changed(old_path=oldpath);
    # </editor-fold>


    @property
    def root_path(self):
        return self.getLabel("root_path");
    # </editor-fold>


    def setRootPath(self, root_path):
        raise NotImplementedError;

    def _setRootPath(self, value):
        self.setLabel("root_path", value);


    def parts(self):
        parts = [];
        split = os.path.split(self.getAbsolutePath());
        while(split[1]!=''):
            parts.append(split[1]);
            split = os.path.split(split[0]);
        parts.append(split[0]);
        parts.reverse()
        return parts;

    # <editor-fold desc="Property: 'md5_string'">
    @property
    def _md5(self):
        if(self._md5_string is None):
            self._md5 = self._getFilePathMD5String();
        return self._md5_string;
    @property
    def _md5_string(self):
        return self.getLabel("md5_string");
    @_md5.setter
    def _md5(self, value):
        self._md5_string=value;
    @_md5_string.setter
    def _md5_string(self, value):
        self.setLabel('md5_string', value);
    # </editor-fold>



    # @property
    # def file_path(self):
    #     return self.getFilePath();
    @property
    def file_name(self):
        return self.getFileName()
    @property
    def file_name_base(self):
        return self.getFileNameBase()
    @property
    def file_ext(self):
        return self.getFileExtension();

    def getAbsolutePath(self, from_root=None):
        root_path = from_root;
        if(root_path is None):
            root_path = self.root_path;
        if(root_path is not None):
            return os.path.abspath(os.path.join(self.root_path, self.file_path));
        else:
            return os.path.abspath(self.file_path);

    # def withDifferentExtension(self, ext):
    #     current = self.file_path;
    #     return os.path.splitext(current)[0] + ext;

    def getPathWithDifferentExtension(self, new_ext):
        current = self.file_path;
        return os.path.splitext(current)[0] + new_ext;


    def on_path_changed(self, old_path=None, **kwargs):
        """
        Anything that should be done when _setFilePath changes the path.
        :param new_path:
        :param old_path:
        :param kwargs:
        :return:
        """
        # self._md5 = None;
        return;

    def getFileName(self):
        filepath = self.file_path
        if (filepath is not None):
            return os.path.basename(self.file_path);

    def getParentDirName(self):
        return os.path.split(self.getDirectoryPath())[-1]

    def getFileExtension(self):
        filename = self.file_name
        if (filename is not None):
            name_parts = os.path.splitext(self.getFileName());
            return name_parts[1];

    def getFileNameBase(self):
        filename = self.file_name
        if (filename is not None):
            name_parts = os.path.splitext(self.getFileName());
            return name_parts[0];

    def getDirectoryPath(self):
        filepath = self.file_path
        if (filepath is not None):
            if(os.path.isdir(self.file_path)):
                return filepath;
            else:
                return os.path.dirname(filepath);



    def isFile(self):
        return os.path.isfile(self.file_path);

    def isDir(self):
        return os.path.isdir(self.file_path);

    def exists(self, from_root=None):
        fpath = self.file_path;
        if(from_root is not None):
            fpath = os.path.join(from_root, fpath);
        return os.path.exists(fpath);

    def initFromDictionary(self, d):
        super(HasFPath, self).initFromDictionary(d);
        # self._file_path = d['file_path'];

    def showInFinder(self):
        try:
            if(apy.defines.HAS_FILEUI):
                apy.afileui.Show(self.getAbsolutePath());
        except NameError as e:
            print(e)

    # def openFile(self):
    #     fileui.Open(self.file_path);

    def _getFilePathMD5String(self):
        return hashlib.md5(self.file_path.encode('utf-8')).hexdigest();

    def getPathWithSuffix(self, suffix, extension=None):
        if(extension is None):
            extension = self.getFileExtension();
        return os.path.join(self.getDirectoryPath(),self.getFileNameBase()+suffix+extension);

    def relative_path(self, to_path=None, from_root=None):
        fpath = self.getAbsolutePath(from_root=from_root);
        if(to_path is None):
            return os.path.relpath(fpath);
        else:
            return os.path.relpath(fpath, to_path);

    def GetPathStringFromRoot(self, root_path):
        return os.path.join(root_path, self.file_path);
