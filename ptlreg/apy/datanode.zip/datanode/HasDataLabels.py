import numpy as np
import pandas as pd
import pandera


class LabelValidationError(Exception):
    def __init__(self, labelKey, value, message=None):
        self.key = labelKey;
        self.value = value;
        self.message=message;
        super(LabelValidationError, self).__init__(self.message)




class HasDataLabels(object):
    DATALABEL_SCHEMA = pandera.DataFrameSchema();
    DATALABELS_DICT_KEY = "data_labels";
        # "__data_labels__"

    @classmethod
    def VALIDATE_TIMESTAMP(cls, value):
        return value;

    def __init__(self, *args, **kwargs):
        self._setDataLabels(None);
        super(HasDataLabels, self).__init__(*args, **kwargs)
        if(self.data_labels is None):
            self._setDataLabels(self.__class__._NewSeries());


    @classmethod
    def _NewSeries(cls, *args, **kwargs):
        return pd.Series(*args, **kwargs);


    @classmethod
    def ValidateDataLabels(cls, data_labels):
        if(isinstance(data_labels, HasDataLabels)):
            return cls.DATALABEL_SCHEMA.validate(data_labels.data_labels);
        return cls.DATALABEL_SCHEMA.validate(data_labels);

    def validateDataLabels(self):
        return self.__class__.ValidateDataLabels(self.data_labels);

    def getDataLabelsDataFrame(self):
        return pd.DataFrame([self.data_labels]);



    def _setDataLabels(self, data_labels):
        self._data_labels = data_labels;

    @property
    def data_labels(self):
        return self._data_labels;


    @classmethod
    def FromSeries(cls, series):
        return cls(data_labels=series);

    # def getLabel(self, key):
    #     return self.data_labels[key];

    def setLabel(self, key, value):
        self.data_labels[key]=value;

    def hasLabel(self, key):
        return key in self.data_labels;

    def getLabel(self, key):
        """
        Wrapper for data_labels that returns None if:
         - the label is not set
         - the label is NAN
         - the label is None
        :param key:
        :return:
        """
        if((key in self.data_labels) and (self.data_labels is not np.NaN)):
            return self._getLabel(key);
        else:
            return None;



    def _getLabel(self, key):
        return self.data_labels[key]

    def hasTag(self, key):
        return (self.hasLabel(key) and (self.getLabel(key)));

    def addLabel(self, key, value=True):
        if(self.hasLabel(key)):
            raise LabelValidationError(labelKey=key, value=value, message="Tried to add label that already exists");
        else:
            self.setLabel(key, value);
        # self.data_labels.append(labelInstance);

    def addTagLabel(self, tag):
        if (self.hasLabel(tag)):
            raise LabelValidationError(labelKey=tag, value=True, message="Tried to add label that already exists");
        else:
            self.setLabel(tag, True);

    def setTagLabel(self, tag, value=True):
        self.setLabel(tag, value);

        # if(self.hasTag(tag)):
        #     return;
        # self.addTagLabel(tag, visible, editable);

    # def removeTagLabel(self, tag):
    #     toRemove = None;
    #     for label in self.data_labels:
    #         if(label.key == tag):
    #             toRemove = label;
    #             break;
    #     if(toRemove is not None):
    #         self.data_labels.remove(toRemove);

    def addStringLabel(self, key, value):
        if value is not type(str):
            value = str(value)
        self.addLabel(key, value);
        # self.data_labels.append(StringLabel(key, value, visible, editable));

    def addTimestampLabel(self, key, value, visible=False, editable=False):
        timestamp = self.__class__.VALIDATE_TIMESTAMP(value);
        self.setLabel(key, timestamp);
        # self.data_labels.append(TimestampLabel(key, value, visible, editable));
    
    # def addFromType(self, key, type, value, visible=False, editable=False):
    #     """
    #         Use this function to automatically add data_labels based on type.
    #         Currently accepted types include "string", "timestamp (date)" and "tag (bool)".
    #     """
    #     if(type == "string"):
    #         self.addStringLabel(key, value, visible, editable);
    #     elif(type == "timestamp"):
    #         self.addTimestampLabel(key, value, visible, editable);
    #     elif(type == "tag"):
    #         self.addTagLabel(value, visible, editable);
    #     # eventually add these categories
    #     # elif(type == "scalar"):
    #     #     self.addScalarLabel(key, value);
    #     # elif(type == "vector"):
    #     #     self.addVectorLabel(key, value);
    #     else:
    #         raise Exception("Unknown label type:{} for key: {}".format(type, key));


    def toDictionary(self):
        d = {};
        if (hasattr(super(HasDataLabels, self), 'toDictionary')):
            d = super(HasDataLabels, self).toDictionary();
        d[self.__class__.DATALABELS_DICT_KEY]=self.data_labels.to_dict();
        return d;

    def initFromDictionary(self, d):
        if (hasattr(super(HasDataLabels, self), 'initFromDictionary')):
            super(HasDataLabels, self).initFromDictionary(d);
        self._setDataLabels(self.__class__._NewSeries(d[self.__class__.DATALABELS_DICT_KEY]));


    # </editor-fold>