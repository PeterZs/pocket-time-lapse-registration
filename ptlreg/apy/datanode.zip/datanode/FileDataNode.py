from .FPath import *
from .DataNode import *
import pandera as pa;
import pandas as pd;

class FileDataNodePathDoesNotExistError(Exception):
    def __init__(self, filenode, message=None):
        self.filenode = filenode;
        self.message=message;
        super(FileDataNodePathDoesNotExistError, self).__init__(self.message)

class HasFileDataNode(HasFPath):
    DATANODE_SCHEMA = pa.DataFrameSchema({
        "file_path": pa.Column(str)
    });


    def __init__(self, path=None, root_path=None, **kwargs):
        """
        Initialize FileDataNode. This is a node that represents a file with a path.
        :param path: The path
        :param kwargs:
        """
        super(HasFileDataNode, self).__init__(path=path, root_path=root_path, **kwargs);

    def __str__(self):
        return '[{}]:{}'.format(self.__class__.__name__, self.file_path);
    def __repr__(self):
        return '[{}]:{}'.format(self.__class__.__name__, self.file_path);

    @classmethod
    def ValidateFileDataNodePath(cls, node, root_path=None):
        if(node.exists(from_root=root_path)):
            return True;
        else:
            raise FileDataNodePathDoesNotExistError(node, "File Does Not Exist!!!");

    @classmethod
    def FileDataNodeFromPath(cls, path, root_path=None, validate=True):
        newnode = cls(path=path, root_path=root_path);
        if(validate):
            cls.ValidateFileDataNodePath(newnode);
        return newnode;

    # <editor-fold desc="Property: 'created_timestamp'">
    @property
    def created_timestamp(self):
        created = self.getLabel("created_timestamp");
        if(created is None):
            self.setLabel("created_timestamp", os.path.getctime(self.getAbsolutePath()));
    # </editor-fold>



class FileDataNode(HasFileDataNode, DataNode):
    pass;