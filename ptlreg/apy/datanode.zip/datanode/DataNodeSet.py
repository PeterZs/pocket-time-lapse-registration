from .HasDataNodeSet import *
from .DataNode import *
import pandas as pd

DATANODESET_EXTENSIONS_DICT = {}
_DATANODESET_TYPES = {}


def register_nodeset_class(cls_to_register):
    assert hasattr(
        cls_to_register, "DATANODESET_FILE_EXTENSIONS"
    ), "Subclass {} of DataNodeSet must implement MEDIA_FILE_EXTENSIONS().".format(
        cls_to_register.DataNodeTypeName()
    )
    exts = cls_to_register.DATANODESET_FILE_EXTENSIONS
    for e in exts:
        existing_class = DATANODESET_EXTENSIONS_DICT.get(e)
        if existing_class is not None:
            assert issubclass(
                cls_to_register, existing_class
            ), "Cannot register extension {} to both {} and {} classes".format(
                e, cls_to_register, existing_class
            )
        DATANODESET_EXTENSIONS_DICT[e] = cls_to_register

    old_class = _DATANODESET_TYPES.get(cls_to_register.DataNodeTypeName())

    # TODO: This should probably be put back if you want to be safe
    # assert(old_class is None), "tried to register MediaObject class {} twice:\nold: {}\nnew: {}".format(cls_to_register.__name__, old_class, cls_to_register);

    _DATANODESET_TYPES[cls_to_register.DataNodeTypeName()] = cls_to_register


class DataNodeSetMeta(DataNodeMeta):
    def __new__(cls, *args, **kwargs):
        newtype = super(DataNodeSetMeta, cls).__new__(cls, *args, **kwargs)
        register_nodeset_class(newtype)
        return newtype

    def __init__(cls, *args, **kwargs):
        return super(DataNodeSetMeta, cls).__init__(*args, **kwargs)

    def __call__(cls, *args, **kwargs):
        supercall = super(DataNodeSetMeta, cls).__call__(*args, **kwargs)
        return supercall


class DataNodeSet(HasDataNodeSet, DataNode):
    """
    You don't need to use DataNodeSet class if you don't want to use the meta class for registering.
    You can just use HasDataNodeSet.
    """

    DATANODESET_SUBSET_CLASS = None
    DEFAULT_INDEX_KEY = None
    DATA_FRAME_CLASS = pd.DataFrame

    @classmethod
    def GetDefaultIndexKey(cls):
        return cls.DEFAULT_INDEX_KEY

    def setNodes(self, nodes, validate=True):
        if validate:
            self.__class__._ValidateDataNodeSetDataFrame(nodes)
        self._nodes = nodes

    def __str__(self):
        return "{}: {}".format(self.__class__.__name__, self.nodes.__str__())

    def __repr__(self):
        return self.nodes.__repr__()

    @property
    def nodes(self):
        return self._nodes

    @nodes.setter
    def nodes(self, nodes):
        self.setNodes(nodes)

    # def __next__(self):  # Python 2: def next(self)
    #     self.current += 1
    #     if self.current < self.high:
    #         return self.current
    #     raise StopIteration

    def _setNode(self, node):
        self._nodes.loc[node.getLabel(self.index_key)] = node.getSeries()


def DataNodeSetMethod(func):
    setattr(DataNodeSet, func.__name__, func)
    return getattr(DataNodeSet, func.__name__)


# @six.add_metaclass(DataNodeSetMeta)
class RegisteredDataNodeSet(six.with_metaclass(DataNodeSetMeta, DataNodeSet)):
    DATANODESET_FILE_EXTENSIONS = [".nodeset"]
    pass
