import pandera as pa;
import six
from .HasDataLabels import *

DataNodeClasses = {};


def register_node_class(cls_to_register):
    assert(hasattr(cls_to_register, 'DataNodeTypeName'));
    if(DataNodeClasses.get(cls_to_register.DataNodeTypeName()) is not None):
        print("WARNING!!!!!:DataNodeTypeName {} already used by {}\nold class: {}\nnew class: {}!".format(
        cls_to_register.DataNodeTypeName(), cls_to_register.__name__, DataNodeClasses.get(cls_to_register.DataNodeTypeName()), cls_to_register))
    DataNodeClasses[cls_to_register.DataNodeTypeName()] = cls_to_register;

class DataNodeMeta(type):
    """
    Meta-class that is used to register DataNode classes.
    """
    def __new__(cls, *args, **kwargs):
        newtype = super(DataNodeMeta, cls).__new__(cls, *args, **kwargs);
        register_node_class(newtype);
        return newtype;

    def __init__(cls, *args, **kwargs):
        super(DataNodeMeta, cls).__init__(*args, **kwargs);


    def __call__(cls, *args, **kwargs):
        supercall = super(DataNodeMeta, cls).__call__(*args, **kwargs);
        return supercall;

@six.add_metaclass(DataNodeMeta)
class DataNode(HasDataLabels):
    '''
        Mixin for nodes. IMPORTANT!!!: There should be no properties stored outside of data_labels!!!
    '''
    DATANODE_SCHEMA = pa.DataFrameSchema();

    @property
    def uid(self):
        raise NotImplementedError;

    @classmethod
    def ValidateDataLabels(cls, data_labels):
        return cls.DATANODE_SCHEMA.validate(pd.DataFrame([data_labels]));

    @classmethod
    def ValidateDataNode(cls, node):
        return cls.DATANODE_SCHEMA.validate(node.getDataLabelsDataFrame());

    @classmethod
    def DataNodeTypeName(cls):
        """
        If you have class name collisions (e.g. same name different module) you can specify the name to use for this
        class type here. Ideally, you should use the longer version of the class name, e.g., 'apy.AObject'.
        :return:
        """
        return cls.__name__;

    def __init__(self, *args, **kwargs):
        super(DataNode, self).__init__(*args, **kwargs);

    @classmethod
    def CreateWithID(cls, id, *args, **kwargs):
        rval = cls(*args, **kwargs);
        rval.setNodeID(id);
        return rval;

    @classmethod
    def FromSeries(cls, series):
        newNode = cls();
        newNode._setDataLabels(series);
        return newNode;


    def setNodeID(self, id):
        self.node_id = id;


    def saveDataLabelsToCSV(self, path):
        self.data_labels.to_csv(path);

    def loadDataLabelsFromCSV(self, path):
        df = pd.read_csv(path);
        self._setDataLabels(df.loc[0]);


    def __getitem__(self, key):
        return self.data_labels.__getitem__(key)

    def __setitem__(self, key, newvalue):
        return self.data_labels.__setitem__(key, newvalue);


    # <editor-fold desc="Property: 'name'">
    @property
    def name(self):
        return self.getLabel("name");
    @name.setter
    def name(self, value):
        self.setLabel("name", value);
    # </editor-fold>

    # <editor-fold desc="Property: 'node_id'">
    @property
    def node_id(self):
        return self.getLabel("node_id");
    @node_id.setter
    def node_id(self, value):
        self.setLabel("node_id", value);
    # </editor-fold>

    def getSeries(self):
        return self.data_labels;

    # def getDataNodeID(self):
    #     raise NotImplementedError;

    # def setDataNodeID(self, value):
    #     raise NotImplementedError;
    #
    # @property
    # def node_id(self):
    #     return self.getDataNodeID();