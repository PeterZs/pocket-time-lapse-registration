from .FPath import *
import shutil
from distutils.dir_util import copy_tree

def _pathstring(path):
    return path.replace(os.sep+os.sep, os.sep);




def MYWARNING(message):
    print(message)

class HasDirectoriesMixin(object):
    """
    Will assume that this is mixed in with HasDataLabels
    """

    # @staticmethod
    # def AObjectType():
    #     return 'SavesDirectoriesMixin';

    def __init__(self, path=None, **kwargs):
        """
        If you provide a directory, it will look for an existing SavesDirectoriesMixin.json in that directory, or create one if it does not already exist. If you provide the path to an existing json, it will use that json. If you provide a path to anything else it will complain...
        :param path:
        :param kwargs: if you include 'clear_temp=False' then it will not clear the temp directory upon creation
        """
        self._resetDirectories();
        super(HasDirectoriesMixin, self).__init__(path=path, **kwargs);
        if(kwargs.get('clear_temp', True)):
            self.clearTempDir();

    @property
    def managed_dir(self):
        return self.getDirectoryPath();

    def _resetDirectories(self):
        self.directories = {};

    def _getAdjustedInputFilePath(self, input_file_path):
        """
        If provided an input file path, infers the actual file path to look for.
        Generally, if you provide a directory path, returns the path to the default JSON name inside that directory
        :param input_file_path:
        :return:
        """
        # return super(SavesDirectoriesMixin, self)._getAdjustedInputFilePath(input_file_path);
        adjusted_path = input_file_path;
        if(adjusted_path is None):
            return None;
        fpath = FPath(input_file_path);
        if(fpath.looks_like_dir):
            adjusted_path = os.path.join(adjusted_path, self.defaultJSONName());
        return adjusted_path;

    def _setFilePath(self, file_path=None, **kwargs):
        super(HasDirectoriesMixin, self)._setFilePath(file_path=file_path, **kwargs);

    def _initAfterFilePathSet(self, **kwargs):
        super(HasDirectoriesMixin, self)._initAfterFilePathSet(**kwargs);
        self.initDirs();

    def initDirs(self, **kwargs):
        self.addDirIfMissing(name='misc', folder_name="Misc");
        if(self.getDir('backup') is None):
            self.setDir('backup', _pathstring(self.getDir('misc', absolute_path=False) + "Backups" + os.sep));
        FPath.make_sure_dir_exists(self.getDir('backup', absolute_path=True))
        if (self.getDir('temp') is None):
            self.setDir('temp', _pathstring(self.getDir('misc', absolute_path=False) + "TEMP" + os.sep));
        FPath.make_sure_dir_exists(self.getDir('temp', absolute_path=True))

    def relativePath(self, path):
        return os.path.relpath(path, start=self.managed_dir)

    def getTempDir(self, absolute_path = True):
        return self.getDir('temp', absolute_path = absolute_path);

    def clearTempDir(self):
        self.emptyDir(name='temp');

    def on_path_change(self, new_path=None, old_path=None, **kwargs):
        """
        Anything that should happen when _setFilePath changes the path. For example, if we save an object to a json, move the json, and then load it, then the path will change from where the object was last saved to where the object was last loaded.
        :param new_path:
        :param old_path:
        :param kwargs:
        :return:
        """

        def prefix_removed(text, prefix):
            if text.startswith(prefix):
                return text[len(prefix):]
            return text


        if(new_path is None or old_path is None):
            return super(HasDirectoriesMixin, self).on_path_change(new_path=new_path, old_path=old_path, **kwargs);
        new_abs_path = os.path.abspath(new_path);
        old_abs_path = os.path.abspath(old_path);
        if(new_abs_path != old_abs_path):
            # print("Converting path from {} to {}".format(old_path, new_path));
            oldir = FPath.Get_dir_from_path(_pathstring(old_abs_path));
            newdir = FPath.Get_dir_from_path(_pathstring(new_abs_path));
            if (oldir != newdir):
                # AWARN("{} FOUND FILE MOVED FROM:\n{}\nTO:\n{}\nUPDATING DIRECTORIES...".format(self.AObjectTypeName(), oldir, newdir));
                for d in self.directories:
                    dpth = self.directories[d];

                    if (os.path.isabs(dpth) and dpth.startswith(oldir)):
                        dpthst = prefix_removed(dpth, oldir);
                        self.directories[d] = os.path.join(newdir, dpthst);
                        MYWARNING("Directory path {} updated to {}".format(dpth, self.directories[d]));

        return super(HasDirectoriesMixin, self).on_path_change(new_path=new_path, old_path=old_path, **kwargs);

    def setDir(self, name, path):
        self.directories[name]=path;
        full_path = self.getDir(name, absolute_path=True);
        FPath.Make_sure_path_exists(full_path);
        return path;

    def addDir(self, name, folder_name = None):
        assert(name not in self.directories), "tried to add {} dir to SavesDirectoriesMixin, but this dir is already set".format(name)
        if(folder_name is None):
            folder_name = name;
        return self.setDir(name, _pathstring('.' + os.sep + folder_name + os.sep));
        # return self.setDir(name, pathstring(self.getDirectoryPath() + os.sep + folder_name + os.sep));

    def addDirIfMissing(self, name, folder_name=None):
        if(name in self.directories):
            # if(not os.path.exists(self.getDir(name))):
            FPath.Make_sure_dir_exists(self.getDir(name, absolute_path=True));
            return;
        else:
            self.addDir(name=name, folder_name=folder_name);


    def addSubDirIfMissing(self, name, parent_name, folder_name):
        if (name in self.directories):
            FPath.Make_sure_dir_exists(self.getDir(name, absolute_path=True));
            return;
        else:
            self.setDir(name,
                        _pathstring(self.getDir(parent_name, absolute_path=False) + folder_name + os.sep));
            FPath.Make_sure_dir_exists(self.getDir(name, absolute_path=True));

    def getDir(self, name, absolute_path = True):
        dir_path = self.directories.get(name);
        if(dir_path is None):
            return None;
        if(not os.path.isabs(dir_path) and absolute_path):
            dir_path = self._toAbsolutePath(dir_path);
        return dir_path;

    def _toAbsolutePath(self, path):
        """
        If path is relative, returns the absolute path assuming path is relative to the directorypath of this object. Is path is already absolute, it gets returned;
        :param path:
        :return:
        """
        path_is_relative = (path and not os.path.isabs(path));
        if(path_is_relative):
            base_dir = self.getDirectoryPath();
            if(base_dir is None):
                return None;
            apath = os.path.abspath(os.path.join(base_dir, path));
            if(path[-1] == os.sep):
                apath = apath+os.sep;
            return apath;
        else:
            return path;

    def emptyDir(self, name, really=False):
        if (not really):
            MYWARNING("DID YOU ACCIDENTALLY TRY TO EMPTY `{}` DIRECTORY???".format(name))
        dpth = self.getDir(name, absolute_path=True);
        if(dpth is not None and os.path.isdir(dpth)):
            shutil.rmtree(dpth);
            FPath.Make_sure_path_exists(dpth);

    def deleteAllDirs(self, really=False):
        if(not really):
            MYWARNING("DID YOU ACCIDENTALLY TRY TO DELETE ALL DIRECTORIES???")
        for d in self.directories:
            dpth = self.getDir(d, absolute_path=True);
            if (dpth is not None and os.path.isdir(dpth)):
                shutil.rmtree(dpth);
        self.directories = {};

    def emptyAllDirs(self, really=False):
        if (not really):
            MYWARNING("DID YOU ACCIDENTALLY TRY TO EMPTY ALL DIRECTORIES???")
        for d in self.directories:
            self.emptyDir(d);


    def deleteDir(self, name, really=False):
        if (not really):
            MYWARNING("DID YOU ACCIDENTALLY TRY TO EMPTY `{}` DIRECTORY???".format(name))
        dpth = self.getDir(name, absolute_path=True);
        if (dpth is not None and os.path.isdir(dpth)):
            shutil.rmtree(dpth);
            d = dict(self.directories);
            del d[name];
            self.directories=d;

    def _DELETE_MANAGED_DIRECTORY(self, really=False):
        """
        Deletes the root of the SavesDirectoriesMixin object. This will delete all of the internal directories as well.
        :return:
        """
        if (not really):
            MYWARNING("DID YOU ACCIDENTALLY TRY TO DELETE MAMAGED DIRECTORY???")
        shutil.rmtree(self.getDirectoryPath());

    def toDictionary(self):
        d = super(HasDirectoriesMixin, self).toDictionary();
        d['directories']=self.directories;
        #serialize class specific members
        return d;

    def copyPathToDir(self, path_to_copy, dest_dir):
        dest_path = self.getDir(dest_dir, absolute_path=True);
        if(dest_path):
            if(os.path.isdir(path_to_copy)):
                copy_tree(src=path_to_copy, dst=dest_path);
            elif(os.path.isfile(path_to_copy)):
                shutil.copy2(path_to_copy, dest_path)
        return;

    def copyDirToPath(self, dir_to_copy, dest_path):
        src_path = self.getDir(dir_to_copy, absolute_path=True);
        if(src_path):
            if(os.path.isdir(dest_path)):
                copy_tree(src=src_path, dst=dest_path);
        return;

    def initFromDictionary(self, d):
        self._resetDirectories();
        super(HasDirectoriesMixin, self).initFromDictionary(d);
        self.directories = d['directories'];



    def saveJSON(self, json_path=None, on_file_exists='backup', **kwargs):
        save_path = json_path;
        if(save_path is None):
            save_path = self.getFilePath();
        assert(save_path.lower().endswith(self._CLASS_JSON_FILE_EXTENSION())), "Directory info saves to json: cannot save to path '{}'".format(save_path);
        if (os.path.isfile(save_path)):
            if(on_file_exists.lower() == 'fail'):
                assert(False), "File {} already exists.".format(save_path);
            elif (on_file_exists.lower() == 'replace'):
                MYWARNING("Replacing file {}".format(save_path));
            else:
                os.rename(save_path, self.getDir('backup', absolute_path=True)+os.sep+os.path.basename(save_path));

        return super(HasDirectoriesMixin, self).saveJSON(json_path=save_path, **kwargs)
        # self.writeToJSON(save_path);

